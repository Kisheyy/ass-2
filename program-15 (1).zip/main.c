#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MAX 1000
int main() 
{
    int h, n,r[MAX];
    int i, t = 0;
    printf("Enter the number of disk requests: ");
    scanf("%d", &n);
    printf("Enter the requests: ");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &r[i]);
    }
    printf("Enter the initial head position: ");
    scanf("%d", &h);
    printf("The request queue is: ");
    for (i = 0; i < n; i++) 
    {
        printf("%d ", r[i]);
    }
    printf("\n");
    printf("The head position is: %d\n", h);
    for (i = 0; i < n; i++) 
    {
        int d = abs(r[i] - h);
        t += d;
        h= r[i];
    }
    printf("The total head movement is: %d\n", t);
    printf("The average head movement is: %.2f\n", (float) t/ n);
    return 0;
}

